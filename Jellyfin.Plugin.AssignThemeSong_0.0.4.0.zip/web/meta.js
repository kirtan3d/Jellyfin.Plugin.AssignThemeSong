define([], function () {
    'use strict';

    return {
        name: 'Assign Theme Song',
        type: 'menuitem',
        id: 'assignThemeSong',
        icon: 'music_note',
        displayName: 'Assign Theme Song',
        pluginId: '6A7B8C9D-0E1F-2345-6789-ABCDEF012345'
    };
});
